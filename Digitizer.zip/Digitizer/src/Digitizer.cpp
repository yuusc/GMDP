/*
  Digitizer.cpp

  Ver1.1.0 Change device usage as Mouse

  by jtakao
*/

#include "Digitizer.h"

#if defined(_USING_HID)

#define LSB(_x) ((_x) & 0xFF)
#define MSB(_x) ((_x) >> 8)

static const uint8_t _hidReportDescriptor[] PROGMEM = {
// Digitizer
    0x05, 0x01,                    // USAGE_PAGE (Generic Desktop)  // 54
    0x09, 0x02,                    // USAGE (Mouse)

	0xa1, 0x01,                    // COLLECTION (Application) 
    0x09, 0x01,                    //   USAGE (Pointer)

	0xa1, 0x00,                         //   COLLECTION (Physical)
	0x85, 0x04,                         //   REPORT_ID (4) 
	
    0x05, 0x09,                    //     USAGE_PAGE (Button)
    0x19, 0x01,                    //     USAGE_MINIMUM (Button 1)
    0x29, 0x03,                    //     USAGE_MAXIMUM (Button 3)
	
	0x15, 0x00,                         //     LOGICAL_MINIMUM (0)
	0x25, 0x01,                         //     LOGICAL_MAXIMUM (1) 
	0x75, 0x01,                         //     REPORT_SIZE (1) 
	0x95, 0x05,                         //     REPORT_COUNT (5)
	0x81, 0x02,                         //     INPUT (Data,Var,Abs) 
	0x95, 0x0b,                         //     REPORT_COUNT (11)
	0x81, 0x03,                         //     INPUT (Cnst,Var,Abs)
	0x05, 0x01,                         //     USAGE_PAGE (Generic Desktop)
	0x75, 0x10,                         //     REPORT_SIZE (16) 
	0x95, 0x01,                         //     REPORT_COUNT (1) 
	0x55, 0x0d,                         //     UNIT_EXPONENT (-3)
	0x65, 0x33,                         //     UNIT (Inch,EngLinear)
	0x15, 0x00,                         //     LOGICAL_MINIMUM (0)
	0x26, 0xff, 0x7f,                   //     LOGICAL_MAXIMUM (32767)
	0x09, 0x30,                         //     USAGE (X)
	0x81, 0x02,                         //     INPUT (Data,Var,Abs) 
	0x09, 0x31,                         //     USAGE (Y) 
	0x81, 0x02,                         //     INPUT (Data,Var,Abs) 
	0xc0,                               //   END_COLLECTION
	0xc0,                               // END_COLLECTION 
};

//================================================================================
//================================================================================
//	Digitizer

Digitizer_::Digitizer_(void)
{
    static HIDSubDescriptor node(_hidReportDescriptor, sizeof(_hidReportDescriptor));
    HID().AppendDescriptor(&node);
	
	logicalMinX = logicalMinY = screenX0 = screenY0 = 0;
	logicalMaxX = logicalMaxY = screenY0 = screenY1 = 32767;
	_switch = 0;
}

void Digitizer_::begin(void) 
{
}

void Digitizer_::end(void) 
{
}

void Digitizer_::setDisplayResolution(int param_x0,int param_y0,int param_x1,int param_y1) {
	screenX0 = param_x0;
	screenX1 = param_x1;
	screenY0 = param_y0;
	screenY1 = param_y1;
}

void Digitizer_::setLogicalResolution(int param_x0,int param_y0,int param_x1,int param_y1) {
	logicalMinX = param_x0;
	logicalMinY = param_y0;
	logicalMaxX = param_x1;
	logicalMaxY = param_y1;
}

void Digitizer_::send() {
	u8 m[6];
//	m[0] = 0x10 | _switch;
	m[0] = 0x00 | _switch;
	m[1] = 0;
	m[2] = LSB(logicalX);
	m[3] = MSB(logicalX);
	m[4] = LSB(logicalY);
	m[5] = MSB(logicalY);
	HID().SendReport(4,m,6);
}

void Digitizer_::move(int paramX, int paramY)
{
	logicalX = map(paramX,screenX0,screenX1,logicalMinX,logicalMaxX);
	logicalY = map(paramY,screenY0,screenY1,logicalMinY,logicalMaxY);
	send();	
}

void Digitizer_::press() {
	_switch = 1;
	send();
}

void Digitizer_::release() {
	_switch = 0;
	send();
}

void Digitizer_::click() {
	press();
	release();
}

Digitizer_ Digitizer;

#endif
