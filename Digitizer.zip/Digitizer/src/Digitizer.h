/*
  Digitizer.h

  by jtakao
*/

#ifndef DIGITIZER_h
#define DIGITIZER_h

#include "HID.h"

#if !defined(_USING_HID)

#warning "Using legacy HID core (non pluggable)"

#else

//================================================================================
//================================================================================
//	Digitizer

class Digitizer_
{
private:
	int screenX0,screenY0,screenX1,screenY1;
	int logicalMinX,logicalMinY,logicalMaxX,logicalMaxY;
	int logicalX, logicalY;
	uint8_t _switch;
	void send();
public:
	Digitizer_(void);
	void begin(void);
	void end(void);
	void setDisplayResolution(int x0, int y0, int x1, int y1);
	void setLogicalResolution(int x0, int y0, int x1, int y1);
	void press();
	void release();
	void click();
	void move(int x, int y);	
};
extern Digitizer_ Digitizer;

#endif
#endif